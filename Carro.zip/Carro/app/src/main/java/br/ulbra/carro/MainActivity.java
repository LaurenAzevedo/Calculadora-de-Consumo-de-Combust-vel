package br.ulbra.carro;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText edtModeloVeiculo, edtPlacaVeiculo,  edtDistancia, edtConsumoMedio, edtPrecoCombustivel;
    TextView txtResultado1 ,txtResultado2;
    Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edtModeloVeiculo = findViewById(R.id.edtModeloVeiculo);
        edtPlacaVeiculo = findViewById(R.id.edtPlacaVeiculo);
        edtDistancia = findViewById(R.id.edtDistancia);
        edtConsumoMedio = findViewById(R.id.edtConsumoMedio);
        edtPrecoCombustivel = findViewById(R.id.edtPrecoCombustivel);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtResultado1 = findViewById(R.id.txtResultado1);
        txtResultado2 = findViewById(R.id.txtResultado2);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double d, cm, pc, result1, result2;
                try {
                    d = Double.parseDouble(edtDistancia.getText().toString());
                    cm = Double.parseDouble(edtConsumoMedio.getText().toString());
                    pc = Double.parseDouble(edtPrecoCombustivel.getText().toString());
                    result1 = d / cm;
                    txtResultado1.setText("Os litros necessários são: " + result1);
                    result2 = result1 * d;
                    txtResultado2.setText(" O custo da viagem é: " + result2);
                } catch (NumberFormatException E){
                    Toast.makeText(MainActivity.this,"Erro na execussão!",Toast.LENGTH_SHORT).show();
                }
            }


        });

        };
    }
